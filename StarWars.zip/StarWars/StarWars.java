/**
 * @author John Manigo        *
 * @version 8 April 2015      *
 * Creates a Star Wars object *
 */
public class StarWars {
	// instance variables
	private String word;
	private int occurrences;
	/**
	 * Default constructor
	 */
	public StarWars(){
		word = null;
		occurrences = 0;
	}
	/**
	 * Parameterized constructor
	 * @param word			A word
	 * @param occurrences	The amount of times the word appears
	 */
	public StarWars(String word, int occurrences) {
		this.word = word;
		this.occurrences = occurrences;
	}
	/**
	 * Gets the word
	 * @return	The word
	 */
	public String getWord() {
		return word;
	}
	/**
	 * Sets the word
	 * @param word	The word
	 */
	public void setWord(String word) {
		this.word = word;
	}
	/**
	 * Gets the occurrences of the word
	 * @return	The amount of times the word appears
	 */
	public int getOccurrences() {
		return occurrences;
	}
	/**
	 * Sets the occurrences of the word
	 * @param occurrences	The amount of times the word appears
	 */
	public void setOccurrences(int occurrences) {
		this.occurrences = occurrences;
	}
	
}
