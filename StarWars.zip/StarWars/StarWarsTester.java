/**
 * @author John Manigo      *
 * @version 8 April 2015    *
 * Tests the Star Wars heap *
 */
import java.util.Scanner;
import java.io.*;
public class StarWarsTester {
	public static void main(String[] args) {
		System.out.println("Scanning Star Wars and sorting the words �force�, �wookiee�, �jabba�, �death star�");
		// create variables for the words and their numbers of occurrences
		String forceName = "force";
		String wookieeName = "wookiee";
		String jabbaName = "jabba";
		String dsName = "death star";
		int forceCount = 0;
		int wookieeCount = 0;
		int jabbaCount = 0;
		int dsCount = 0;
		// create a new StarWarsHeap object
		StarWarsHeap heap = new StarWarsHeap(4);
		try{
			// read from the script file
			Scanner file = new Scanner(new File("StarWarsNewHopeScript.txt"));
			// increase the count for each word as the program encounters them in the script
			for(int i = 0; file.hasNext(); i++){
				String word = file.next();
				if(word.equalsIgnoreCase(forceName) || word.equalsIgnoreCase(forceName + ".")
						|| word.equalsIgnoreCase(forceName + "!")
						|| word.equalsIgnoreCase(forceName + "?")
						|| word.equalsIgnoreCase(forceName + ","))
						forceCount++;
				if(word.equalsIgnoreCase(wookieeName) || word.equalsIgnoreCase(wookieeName + ".")
						|| word.equalsIgnoreCase(wookieeName + "!")
						|| word.equalsIgnoreCase(wookieeName + "?")
						|| word.equalsIgnoreCase(wookieeName + ","))
					wookieeCount++;
				if(word.equalsIgnoreCase(jabbaName)|| word.equalsIgnoreCase(jabbaName + ".")
						|| word.equalsIgnoreCase(jabbaName + "!")
						|| word.equalsIgnoreCase(jabbaName + "?")
						|| word.equalsIgnoreCase(jabbaName + ","))
					jabbaCount++;
				if(word.equalsIgnoreCase("death")){
					word = file.next();
					if(word.equalsIgnoreCase("star")|| word.equalsIgnoreCase("star.")
							|| word.equalsIgnoreCase("star!")
							|| word.equalsIgnoreCase("star?")
							|| word.equalsIgnoreCase("star,"))
						dsCount++;
					else
						continue;
				}
			}
			// stop reading the script file
			file.close();
		}
		catch(FileNotFoundException e){
			System.out.println("The force is weak with this one");
		}
		// create StarWars objects for each word then add them to the heap
		StarWars force = new StarWars(forceName, forceCount);
		StarWars wookiee = new StarWars(wookieeName, wookieeCount);
		StarWars jabba = new StarWars(jabbaName, jabbaCount);
		StarWars ds = new StarWars(dsName, dsCount);
		heap.add(force);
		heap.add(wookiee);
		heap.add(jabba);
		heap.add(ds);
		// print out the sorted heap
		heap.heapSort();
	}
}
