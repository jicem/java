/**
 * @author John Manigo      *
 * @version 8 April 2015    *
 * Creates a Star Wars heap *
 */
public class StarWarsHeap {
	// instance variables
	private StarWars[] heap;
	private static int size;
	/**
	 * Default constructor
	 */
	public StarWarsHeap(){
		heap = new StarWars[100];
		size = 0;
	}
	/**
	 * Parameterized constructor
	 * @param length	The length of the array
	 */
	public StarWarsHeap(int length) {
		heap = new StarWars[length];
		size = 0;
	}
	/**
	 * Adds a new StarWars object to the heap
	 * @param sw	The StarWars object
	 */
	public void add(StarWars sw){
		if(size == heap.length){
			System.out.println("Heap is full");
			return;
		}
		heap[size] = sw;
		bubbleUp();
		size++;
	}
	/**
	 * Bubbles up the heap
	 */
	public void bubbleUp(){
		int index = size;
		while(index>0 && heap[(index-1)/2].getOccurrences()>heap[index].getOccurrences())
		{
			StarWars temp = heap[(index-1)/2];
			heap[(index-1)/2] = heap[index];
			heap[index] = temp;
			index = (index-1)/2;
		}
	}
	/**
	 * Removes the last StarWars object from the heap
	 * @param sw	The StarWars object
	 */
	public StarWars remove(){
		StarWars root = heap[0];
		heap[0] = heap[size - 1];
		heap[size - 1] = null;
		size--;
		bubbleDown();
		return root;
	}
	/**
	 * Bubbles down the heap
	 */
	public void bubbleDown(){
		int index = 0;
		while(index*2+1 < size)
		{
			int bigIndex = index*2+1;
			if(index*2+2 < size && heap[index*2+1].getOccurrences() > heap[index*2+2].getOccurrences())
			{
				bigIndex = index*2+2;
			}
			
			if(heap[index].getOccurrences() > heap[bigIndex].getOccurrences())
			{
				StarWars temp = heap[index];
				heap[index] = heap[bigIndex];
				heap[bigIndex] = temp;
			}
			else
			{
				break;
			}
			index = bigIndex;
		}
	}
	/**
	 * Prints out the sorted heap
	 */
	public void heapSort(){
		StarWarsHeap temp = this;
		for(int i=size;i>0;i--){
			StarWars sw = temp.remove();
			System.out.println("The number of times the word " + sw.getWord() + " appears in Star Wars is " + sw.getOccurrences());
		}
	}
}