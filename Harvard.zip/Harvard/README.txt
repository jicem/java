I created this Java program after seeing an article about an alogrithm introduced on the first day of a Computer Science class at Harvard, hence the name. You can find the article here:

http://finance.yahoo.com/news/took-harvards-incredibly-popular-computer-170214119.html

The program has been edited for clarity.