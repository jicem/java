/* Author: John Manigo */

public class Harvard{
	public static void main(String[] args){
		int num = 400;
		int count = 0;
		int temp = num;
		System.out.println("Harvard Class Simulation");
		System.out.println();
		System.out.println("Number of students: " + num);
		for(int i = 1; i < num; i *= 2){
			if(i >= num) break;
			System.out.println("Dividing by two...");
			temp /= 2;
			System.out.println("Number of students left to count: " + temp);
			count++;
		}
		System.out.println();
		System.out.println("It takes " + count + " steps to count the " + num + " students.");
	}
}