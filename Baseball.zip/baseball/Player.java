/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.baseball;

/**
 *
 * @author John Manigo
 */
public class Player {
    private String name;
    private int strength;
    private int speed;
    private int vision;
    public String getName(){
        return name;
    }
    public int getStrength(){
        return strength;
    }
    public int getSpeed(){
        return speed;
    }
    public int getVision(){
        return vision;
    }
    public void setName(String newName){
        this.name = newName;
    }
    public void setStrength(int str){
        this.strength = str;
    }
    public void setSpeed(int spd){
        this.speed = spd;
    }
    public void setVision(int vis){
        this.vision = vis;
    }
}
