/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.baseball;

/**
 *
 * @author John Manigo
 */
public class PlayBall {
    // method to describe what happens every time a ball is thrown
    static int hitBall(Player hitter){
        double rand = Math.random()*10;
        // ball will only be hit if player sees it properly
        if(rand < hitter.getVision()){
            // regular hit if player swings fast enough
            if(rand < hitter.getSpeed() && rand > hitter.getStrength()){
                return 1;
            }
            // if player swings with the right speed and stength it will be a home run
            if(rand < hitter.getSpeed() && rand < hitter.getStrength()){
                return 2;
            }
        }
        return 0;
    }
    public static void main(String args[]){
        // variable to track the result of each hit
        int hitResult;
        // instantiate player objects
        Player player1 = new Player();
        Player player2 = new Player();
        Player player3 = new Player();
        Player player4 = new Player();
        // set names for each player
        player1.setName("Shohei Ohtani");
        player2.setName("Freddie Freeman");
        player3.setName("Bryce Harper");
        player4.setName("Aaron Judge");
        // set strength for each player
        player1.setStrength(6);
        player2.setStrength(3);
        player3.setStrength(4);
        player4.setStrength(2);
        // set speed for each player
        player1.setSpeed(7);
        player2.setSpeed(8);
        player3.setSpeed(7);
        player4.setSpeed(8);
        // set vision for each player
        player1.setVision(8);
        player2.setVision(6);
        player3.setVision(5);
        player4.setVision(6);
        // print names and ratings for everyone
        System.out.println("Player 1: " + player1.getName());
        System.out.println("Player 2: " + player2.getName());
        System.out.println("Player 3: " + player1.getName());
        System.out.println("Player 4: " + player2.getName());
        System.out.println();
        System.out.println("Player 1 ratings:");
        System.out.println("Speed: " + player1.getSpeed());
        System.out.println("Strength: " + player1.getStrength());
        System.out.println("Vision: " + player1.getVision());
        System.out.println();
        System.out.println("Player 2 ratings:");
        System.out.println("Speed: " + player2.getSpeed());
        System.out.println("Strength: " + player2.getStrength());
        System.out.println("Vision: " + player2.getVision());
        System.out.println();
        System.out.println("Player 3 ratings:");
        System.out.println("Speed: " + player3.getSpeed());
        System.out.println("Strength: " + player3.getStrength());
        System.out.println("Vision: " + player3.getVision());
        System.out.println();
        System.out.println("Player 4 ratings:");
        System.out.println("Speed: " + player4.getSpeed());
        System.out.println("Strength: " + player4.getStrength());
        System.out.println("Vision: " + player4.getVision());
        System.out.println();
        // simulate baseball game
        System.out.println("The pitcher walks up to the mound");
        System.out.println();
        System.out.println("He throws to " + player1.getName());
        hitResult = hitBall(player1);
        switch (hitResult) {
            case 0 -> System.out.println("No good.");
            case 1 -> System.out.println("He gets a hit.");
            case 2 -> System.out.println("He gets a home run!");
            default -> {
            }
        }
        System.out.println();
        System.out.println("He throws to " + player2.getName());
        hitResult = hitBall(player2);
        switch (hitResult) {
            case 0 -> System.out.println("No good.");
            case 1 -> System.out.println("He gets a hit.");
            case 2 -> System.out.println("He gets a home run!");
            default -> {
            }
        }
        System.out.println();
        System.out.println("He throws to " + player3.getName());
        hitResult = hitBall(player3);
        switch (hitResult) {
            case 0 -> System.out.println("No good.");
            case 1 -> System.out.println("He gets a hit.");
            case 2 -> System.out.println("He gets a home run!");
            default -> {
            }
        }
        System.out.println();
        System.out.println("He throws to " + player4.getName());
        hitResult = hitBall(player4);
        switch (hitResult) {
            case 0 -> System.out.println("No good.");
            case 1 -> System.out.println("He gets a hit.");
            case 2 -> System.out.println("He gets a home run!");
            default -> {
            }
        }
    }
}